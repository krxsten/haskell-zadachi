﻿const button = document.querySelector('input[type="button"]');
function calculatePrice()
{
    const name = document.getElementById("name").value
    const pizzaDiv = document.getElementById("pizzaType")
    const pizzaType = pizzaDiv.querySelector("input[name=\"pizza\"]:checked")
    let basePrice = parseFloat(pizzaType.value)
    let sizePrice = parseFloat(document.getElementById("size").value)
    let quantity = parseInt(document.getElementById("quantity").value)
    let total = (basePrice + sizePrice) * quantity
    alert(`Здравей, ${name}! Общата цена на поръчката е ${total} лв.`)
}
button.addEventListener("click", calculatePrice)